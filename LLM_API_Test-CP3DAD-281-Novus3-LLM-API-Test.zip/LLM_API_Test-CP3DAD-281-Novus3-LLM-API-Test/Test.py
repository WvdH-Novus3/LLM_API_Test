
from chatlas import ChatOllama

chat = ChatOllama(model="phi4:latest")
chat.chat("What is the capital of South Africa?")
